import json

def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": json.dumps({
            "status": "ok",
            "status_code": 200
        })
    }
